void initUart( int Speed);
void UartCharTransmit(unsigned char znak);
void UartStringTransmit(char * napis);
