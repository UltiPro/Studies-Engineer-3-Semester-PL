
#define Tx 0x10            // P3.4
#define Rx 0x20            // P3.5

void initPortyUart(void);
